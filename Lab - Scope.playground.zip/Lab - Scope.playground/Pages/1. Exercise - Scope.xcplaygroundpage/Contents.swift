/*:
## Exercise - Scope
 
 Using a comment or print statement, describe why the code below will generate a compiler error if you uncomment line 10.
 */
for _ in 0..<10 {
    let foo = 55
    print("The value of foo is \(foo)")
}

//print("The value of foo is \(foo)")
// Error: 'foo' is not accessible here because 'foo' was declared inside the for-loop scope and is not visible outside of it.


//:  Using a comment or print statement, describe why both print statements below compile when similar-looking code did not compile above. In what scope is `x` defined, and in what scope is it modified? In contrast, in what scope is `foo` defined and used?
var x = 10   // 'x' is declared in the outer/global scope, outside the for-loop

for _ in 0..<10 {
    x += 1   // 'x' is accessed and modified inside the loop, but since it's declared outside, it's still the same variable
    print("The value of x is \(x)")
}

print("The final value of x is \(x)")
// This compiles because 'x' is accessible both inside and outside the loop — it's defined in the outer scope and modified inside the loop.

// In contrast, in the previous example:
// 'foo' was declared *inside* the loop's braces, so its scope was limited to the loop body only.
// Trying to access 'foo' outside the loop caused a compiler error because 'foo' was *not visible* there.

//:  In the body of the function `greeting` below, use variable shadowing when unwrapping `greeting`. If `greeting` is successfully unwrapped, print a statement that uses the given greeting to greet the given name (i.e. if `greeting` successfully unwraps to have the value "Hi there" and `name` is `Sara`, print "Hi there, Sara."). Otherwise, use "Hello" to print a statement greeting the given name. Call the function twice, once passing in a value for greeting, and once passing in `nil`.
func greeting(greeting: String?, name: String) {
    if let greeting = greeting {  // variable shadowing the parameter 'greeting'
        print("\(greeting), \(name).")
    } else {
        print("Hello, \(name).")
    }
}

// Call with a non-nil greeting
greeting(greeting: "Hi there", name: "Sara")  // Prints: Hi there, Sara.

// Call with nil greeting
greeting(greeting: nil, name: "Alex")         // Prints: Hello, Alex.

//:  Create a class called `Car`. It should have properties for `make`, `model`, and `year` that are of type `String`, `String`, and `Int`, respectively. Since this is a class, you'll need to write your own memberwise initializer. Use shadowing when naming parameters in your initializer.
class Car {
    var make: String
    var model: String
    var year: Int

    init(make: String, model: String, year: Int) {
        // Parameter shadowing: parameters have the same names as properties
        self.make = make
        self.model = model
        self.year = year
    }
}


/*:
page 1 of 2  |  [Next: App Exercise - Step Competition](@next)
 */
