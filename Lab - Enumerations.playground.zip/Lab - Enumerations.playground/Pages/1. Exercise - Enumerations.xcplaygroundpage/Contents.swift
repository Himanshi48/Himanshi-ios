/*:
## Exercise - Enumerations
 
 Define a `Suit` enum with four possible cases: `clubs`, `spades`, `diamonds`, and `hearts`.
 */
enum Suit {
    case clubs, spades, diamonds, hearts
}

let mySuit: Suit = .hearts
switch mySuit {
case .clubs:
    print("The suit is Clubs.")
case .spades:
    print("The suit is Spades.")
case .diamonds:
    print("The suit is Diamonds.")
case .hearts:
    print("The suit is Hearts.")
}
//:  Imagine you are being shown a card trick and have to draw a card and remember the suit. Create a variable instance of `Suit` called `cardInHand` and assign it to the `hearts` case. Print out the instance.

var cardInHand: Suit = .hearts

print("The card in your hand is: \(cardInHand)")


//:  Now imagine you have to put back the card you drew and draw a different card. Update the variable to be a spade instead of a heart.
cardInHand = .spades
print("You put back the card and drew a new card. The card in your hand is now: \(cardInHand)")

//:  Imagine you are writing an app that will display a fun fortune (i.e. something like "You will soon find what you seek.") based on cards drawn. Write a function called `getFortune(cardSuit:)` that takes a parameter of type `Suit`. Inside the body of the function, write a switch statement based on the value of `cardSuit`. Print a different fortune for each `Suit` value. Call the function a few times, passing in different values for `cardSuit` each time.
func getFortune(cardSuit: Suit) {
    switch cardSuit {
    case .clubs:
        print("Fortune for Clubs: Your persistence will pay off sooner than you think.")
    case .spades:
        print("Fortune for Spades: A bold move in your near future will bring great rewards.")
    case .diamonds:
        print("Fortune for Diamonds: Wealth is coming your way, both material and spiritual.")
    case .hearts:
        print("Fortune for Hearts: Love will find you when you least expect it.")
    }
}

//:  Create a `Card` struct below. It should have two properties, one for `suit` of type `Suit` and another for `value` of type `Int`.
struct Card {
    enum Value {
            case ace, two, three, four, five, six, seven, eight, nine, ten, jack, queen, king
        }
    var suit: Suit
    var value: Value
}

//:  How many values can playing cards have? How many values can `Int` be? It would be safer to have an enum for the card's value as well. Inside the struct above, create an enum for `Value`. It should have cases for `ace`, `two`, `three`, `four`, `five`, `six`, `seven`, `eight`, `nine`, `ten`, `jack`, `queen`, `king`. Change the type of `value` from `Int` to `Value`. Initialize two `Card` objects and print a statement for each that details the card's value and suit.
// Function to get a string representation of the card value
func cardDescription(card: Card) -> String {
    switch card.value {
    case .ace:
        return "Ace"
    case .two:
        return "Two"
    case .three:
        return "Three"
    case .four:
        return "Four"
    case .five:
        return "Five"
    case .six:
        return "Six"
    case .seven:
        return "Seven"
    case .eight:
        return "Eight"
    case .nine:
        return "Nine"
    case .ten:
        return "Ten"
    case .jack:
        return "Jack"
    case .queen:
        return "Queen"
    case .king:
        return "King"
    }
}
/*:
page 1 of 2  |  [Next: App Exercise - Swimming Workouts](@next)
 */
